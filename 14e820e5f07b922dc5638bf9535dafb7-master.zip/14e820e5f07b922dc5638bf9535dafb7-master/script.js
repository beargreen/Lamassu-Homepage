(window.webpackJsonp = window.webpackJsonp || []).push([[35], {
    "513g": function(e, t, n) {
        "use strict";
        var o = n("PJYZ")
          , a = n.n(o)
          , r = n("VbXa")
          , i = n.n(r)
          , l = n("lSNA")
          , c = n.n(l)
          , s = n("ERkP")
          , u = n("rxPX")
          , m = n("RqPI")
          , p = Object(u.a)().propsFromState({
            currentCountry: m.k
        })
          , d = n("s9SB")
          , g = n.n(d)
          , h = n("6/RC")
          , f = n.n(h)
          , b = n("wrlS")
          , w = n("v6aA")
          , y = n("HPNB")
          , B = n("3XMw")
          , x = n.n(B)
          , E = n("3xO4")
          , S = n.n(E)
          , k = n("0FVZ")
          , v = n("cHvH")
          , I = n("mw9i")
          , C = n("/yvb")
          , W = n("rHpw")
          , _ = x.a.c6d63ac0
          , O = function(e) {
            var t = e.children
              , n = e.onClose
              , o = e.closeLabel;
            return s.createElement(k.a.Persistent, null, s.createElement(v.a, null, (function(e) {
                var a = e.windowWidth
                  , r = y.a.isTwoColumnLayout(a)
                  , i = r ? S.a : I.a;
                return s.createElement(S.a, {
                    style: [L.root, r && P.root]
                }, s.createElement(i, {
                    style: [L.container, r && P.container]
                }, t), s.createElement(S.a, {
                    style: [r && P.closeButtonContainer]
                }, s.createElement(C.a, {
                    onPress: n,
                    size: "normalCompact",
                    style: [L.closeButton, r && P.closeButton],
                    type: "invertedSecondary"
                }, o)))
            }
            )))
        };
        O.defaultProps = {
            closeLabel: _
        };
        var L = W.a.create((function(e) {
            return {
                root: {
                    boxShadow: e.boxShadows.medium,
                    backgroundColor: e.colors.deepGray,
                    padding: e.spaces.xSmall,
                    paddingBottom: "calc(" + e.spaces.xSmall + " + " + W.a.iPhoneOffsetBottom + ")",
                    width: "100%"
                },
                container: {
                    alignItems: "center"
                },
                closeButton: {
                    marginTop: e.spaces.xSmall
                }
            }
        }
        ))
          , P = W.a.create((function(e) {
            return {
                root: {
                    flexDirection: "row"
                },
                container: {
                    alignItems: "flex-start",
                    flexGrow: 1,
                    flexShrink: 1,
                    justifyContent: "center"
                },
                closeButtonContainer: {
                    justifyContent: "center"
                },
                closeButton: {
                    marginTop: 0,
                    flexGrow: 0,
                    flexShrink: 0
                }
            }
        }
        ))
          , j = O
          , z = n("496R")
          , A = n("KpAt")
          , T = function(e) {
            function t() {
                for (var t, n = arguments.length, o = new Array(n), r = 0; r < n; r++)
                    o[r] = arguments[r];
                return t = e.call.apply(e, [this].concat(o)) || this,
                c()(a()(t), "state", {
                    euWarningIsOpen: !1
                }),
                c()(a()(t), "_handleEUBannerClose", (function() {
                    Object(A.b)(),
                    t.setState({
                        euWarningIsOpen: !1
                    })
                }
                )),
                t
            }
            i()(t, e);
            var n = t.prototype;
            return n.UNSAFE_componentWillMount = function() {
                var e = this.props.currentCountry
                  , t = b.a.getArrayValue("responsive_web_eu_countries", [])
                  , n = f.a.canUseDOM ? g.a.parse(document.cookie) : {};
                this.setState({
                    euWarningIsOpen: !!e && Object(A.c)(t, e, n)
                })
            }
            ,
            n.render = function() {
                return !this.props.hideEUBanner && this.state.euWarningIsOpen ? s.createElement(j, {
                    onClose: this._handleEUBannerClose
                }, s.createElement(A.a, null)) : null
            }
            ,
            t
        }(s.PureComponent);
        c()(T, "contextType", w.a),
        c()(T, "defaultProps", {
            hideEUBanner: !1
        });
        t.a = Object(z.a)(p(T))
    },
    KpAt: function(e, t, n) {
        "use strict";
        n.d(t, "c", (function() {
            return d
        }
        )),
        n.d(t, "b", (function() {
            return g
        }
        ));
        n("0rpg");
        var o = n("ERkP")
          , a = n("s9SB")
          , r = n.n(a)
          , i = n("cnVF")
          , l = n("6/RC")
          , c = n.n(l)
          , s = n("3XMw")
          , u = n.n(s)
          , m = n("t62R")
          , p = n("rHpw")
          , d = function(e, t, n) {
            var o = e.indexOf(t.toLowerCase()) > -1
              , a = n[i.h];
            return o && "1" !== a
        }
          , g = function() {
            c.a.canUseDOM && (document.cookie = r.a.serialize(i.h, "1", {
                maxAge: 31536e3,
                path: "/",
                domain: ".twitter.com",
                secure: !0
            }))
        }
          , h = p.a.create((function(e) {
            return {
                link: {
                    textDecorationLine: "underline"
                }
            }
        }
        ));
        t.a = function() {
            return o.createElement(m.b, {
                color: "white",
                size: "small"
            }, o.createElement(u.a.I18NFormatMessage, {
                $i18n: "eb1c2aba"
            }, o.createElement(m.b, {
                color: "white",
                link: "https://help.twitter.com/rules-and-policies/twitter-cookies",
                style: h.link
            }, u.a.f7104ffd)))
        }
    },
    Quhu: function(e, t, n) {
        "use strict";
        t.__esModule = !0,
        t.default = void 0,
        n("PN9k");
        var o = i(n("7DT3"))
          , a = i(n("ERkP"))
          , r = i(n("OkZJ"));
        function i(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var l = function(e) {
            return void 0 === e && (e = {}),
            (0,
            o.default)("svg", Object.assign({}, e, {
                style: [r.default.root, e.style],
                viewBox: "0 0 24 24"
            }), a.default.createElement("g", null, a.default.createElement("path", {
                d: "M16.695 13.037c1.185 0 2.51-.132 3.368-1.11.72-.823.952-2.08.715-3.847-.333-2.478-1.86-3.956-4.083-3.956-2.225 0-3.75 1.48-4.084 3.956-.236 1.766-.002 3.023.717 3.846.858.98 2.184 1.11 3.368 1.11zM14.098 8.28c.134-.992.648-2.656 2.598-2.656 1.948 0 2.463 1.664 2.597 2.655.174 1.293.054 2.187-.358 2.657-.367.42-1.036.6-2.238.6s-1.87-.18-2.24-.6c-.412-.47-.533-1.364-.36-2.658zm9.788 11.222c-.763-3.066-3.72-5.208-7.19-5.208-1.765 0-3.392.558-4.67 1.505-1.278-.948-2.905-1.506-4.67-1.506-3.47 0-6.428 2.142-7.19 5.208-.156.625-.025 1.265.356 1.754.37.473.94.744 1.567.744h19.87c.628 0 1.2-.27 1.57-.745.382-.49.512-1.13.356-1.753zm-1.537.83c-.09.11-.22.168-.39.168h-7.413c.078-.32.084-.66 0-.998-.25-1-.75-1.888-1.41-2.65.993-.665 2.223-1.058 3.558-1.058 2.78 0 5.14 1.674 5.735 4.07.044.174.014.344-.08.467zM7.354 20.5H2.09c-.17 0-.3-.057-.388-.168-.096-.123-.126-.294-.083-.47.596-2.395 2.954-4.068 5.735-4.068 2.78 0 5.14 1.674 5.735 4.07.043.174.014.344-.082.467-.088.113-.22.17-.388.17H7.355zm.001-7.463c1.185 0 2.51-.132 3.367-1.11.72-.823.953-2.08.716-3.847-.333-2.478-1.86-3.956-4.083-3.956-2.225 0-3.75 1.48-4.084 3.956-.236 1.766-.002 3.023.717 3.846.858.98 2.184 1.11 3.368 1.11zM4.758 8.28c.134-.992.648-2.656 2.598-2.656 1.948 0 2.463 1.664 2.597 2.655.174 1.293.053 2.187-.358 2.658-.368.42-1.037.6-2.238.6-1.202 0-1.87-.18-2.24-.6-.412-.47-.533-1.365-.36-2.66z"
            })))
        };
        l.metadata = {
            height: 24,
            width: 24
        };
        var c = l;
        t.default = c
    },
    bojF: function(e, t, n) {
        "use strict";
        n.r(t);
        n("cI1W"),
        n("PN9k");
        var o = n("PJYZ")
          , a = n.n(o)
          , r = n("VbXa")
          , i = n.n(r)
          , l = n("lSNA")
          , c = n.n(l)
          , s = n("ERkP")
          , u = n("513g")
          , m = n("oEGd")
          , p = {
            scribeAction: n("zh9S").c
        }
          , d = Object(m.b)(p)
          , g = n("7JQg")
          , h = n("SrtL")
          , f = n("FQwk")
          , b = n("3XMw")
          , w = n.n(b)
          , y = n("Quhu")
          , B = n.n(y)
          , x = n("zOCl")
          , E = n.n(x)
          , S = n("Gzkc")
          , k = n.n(S)
          , v = n("GQKA")
          , I = n.n(v)
          , C = n("6oVL")
          , W = n("yoO3")
          , _ = n("hqKg")
          , O = n("RqPI")
          , L = Object(_.createSelector)(O.k, (function(e) {
            return {
                currentCountry: e
            }
        }
        ))
          , P = Object(m.c)(L)
          , j = n("s9SB")
          , z = n.n(j)
          , A = n("6/RC")
          , T = n.n(A)
          , H = n("wrlS")
          , F = n("3xO4")
          , M = n.n(F)
          , R = n("cHvH")
          , U = n("rHpw")
          , D = n("mw9i")
          , N = n("/yvb")
          , G = n("KpAt")
          , V = w.a.c6d63ac0
          , J = function(e) {
            function t() {
                for (var t, n = arguments.length, o = new Array(n), r = 0; r < n; r++)
                    o[r] = arguments[r];
                return t = e.call.apply(e, [this].concat(o)) || this,
                c()(a()(t), "_handleEUBannerClose", (function() {
                    Object(G.b)(),
                    t.setState({
                        euWarningIsOpen: !1
                    })
                }
                )),
                t
            }
            i()(t, e);
            var n = t.prototype;
            return n.UNSAFE_componentWillMount = function() {
                var e = this.props.currentCountry
                  , t = H.a.getArrayValue("responsive_web_eu_countries", [])
                  , n = T.a.canUseDOM ? z.a.parse(document.cookie) : {};
                this.setState({
                    euWarningIsOpen: !!e && Object(G.c)(t, e, n)
                })
            }
            ,
            n.render = function() {
                var e = this;
                return this.state.euWarningIsOpen ? s.createElement(R.a, null, (function(t) {
                    var n = t.windowWidth >= U.a.theme.breakpoints.large
                      , o = n ? M.a : D.a;
                    return s.createElement(M.a, {
                        style: [X.root, n && K.root]
                    }, s.createElement(o, {
                        style: [X.euBannerWrapper, n && K.euBannerWrapper]
                    }, s.createElement(G.a, null)), s.createElement(M.a, {
                        style: [n && K.closeButtonContainer]
                    }, s.createElement(N.a, {
                        onPress: e._handleEUBannerClose,
                        size: "normalCompact",
                        style: [X.closeButton, n && K.closeButton],
                        type: "invertedSecondary"
                    }, V)))
                }
                )) : null
            }
            ,
            t
        }(s.Component)
          , X = U.a.create((function(e) {
            return {
                root: {
                    backgroundColor: e.colors.deepGray,
                    boxShadow: e.boxShadows.medium,
                    padding: "" + e.spaces.xSmall,
                    width: "100%"
                },
                euBannerWrapper: {
                    alignItems: "center"
                },
                closeButton: {
                    marginTop: e.spaces.xSmall
                }
            }
        }
        ))
          , K = U.a.create((function(e) {
            return {
                root: {
                    flexDirection: "row"
                },
                euBannerWrapper: {
                    alignItems: "flex-start",
                    flexGrow: 1,
                    flexShrink: 1,
                    justifyContent: "center"
                },
                closeButtonContainer: {
                    justifyContent: "center"
                },
                closeButton: {
                    marginTop: 0,
                    flexGrow: 0,
                    flexShrink: 0
                }
            }
        }
        ))
          , Q = P(J)
          , Z = "signupButton"
          , q = "loginButton"
          , Y = n("t62R")
          , $ = n("XJCT");
        n.d(t, "LoggedOutHome", (function() {
            return le
        }
        ));
        var ee = [{
            text: w.a.a7621206,
            Icon: k.a
        }, {
            text: w.a.a852280c,
            Icon: B.a
        }, {
            text: w.a.fb0da828,
            Icon: E.a
        }]
          , te = w.a.de627493
          , ne = w.a.i71eaa78
          , oe = w.a.e3a98915
          , ae = w.a.f6b6a2e1
          , re = w.a.e8921b67
          , ie = w.a.d6a8e119
          , le = function(e) {
            function t(t) {
                var n;
                return n = e.call(this, t) || this,
                c()(a()(n), "_handleSubmitEditing", (function() {
                    n.setState({
                        autoSubmit: !0
                    })
                }
                )),
                c()(a()(n), "_handleSignupButton", (function() {
                    var e = n.props
                      , t = e.scribeAction
                      , o = e.scribeNamespace;
                    t(Object.assign({}, o, {
                        section: "front",
                        component: "signup_callout",
                        element: "form",
                        action: "signup"
                    }))
                }
                )),
                c()(a()(n), "_handleLoginButton", (function() {
                    var e = n.props
                      , t = e.scribeAction
                      , o = e.scribeNamespace;
                    t(Object.assign({}, o, {
                        section: "front",
                        component: "signup_callout",
                        element: "form",
                        action: "login"
                    }))
                }
                )),
                c()(a()(n), "_handleUsernameChange", (function(e) {
                    n.setState({
                        usernameValue: e.target.value
                    })
                }
                )),
                n.state = {
                    autoSubmit: !1
                },
                n
            }
            i()(t, e);
            var n = t.prototype;
            return n.render = function() {
                var e = this;
                return s.createElement(R.a, null, (function(t) {
                    var n = function(e, t) {
                        return {
                            isScreenLarge: e >= U.a.theme.breakpoints.large,
                            isLoginFormCentered: e / 2 - (e / 4 - 190) < U.a.theme.breakpoints.medium,
                            showLoginForm: e / 2 > 500 && t >= 660
                        }
                    }(t.windowWidth, t.windowHeight)
                      , o = n.isScreenLarge
                      , a = n.isLoginFormCentered
                      , r = n.showLoginForm;
                    return s.createElement(W.a, null, s.createElement(h.a, {
                        title: ie
                    }), s.createElement(M.a, {
                        style: se.root
                    }, s.createElement(M.a, {
                        style: [o && se.blocksWide, se.main]
                    }, s.createElement(M.a, {
                        style: [se.block, o && se.blockWide]
                    }, r ? e._renderLoginForm(a) : null, s.createElement(M.a, {
                        style: se.blockInnerWrapper
                    }, s.createElement(I.a, {
                        style: se.twitterIcon
                    }), s.createElement(Y.b, {
                        size: "jumbo",
                        style: se.seeWhatsHappening,
                        weight: "bold"
                    }, oe), s.createElement(Y.b, {
                        style: se.joinToday,
                        weight: "bold"
                    }, ne), s.createElement(N.a, {
                        link: "/i/flow/signup",
                        onPress: e._handleSignupButton,
                        style: se.happeningButton,
                        testID: Z,
                        type: "primary"
                    }, ae), s.createElement(N.a, {
                        link: "/login",
                        onPress: e._handleLoginButton,
                        style: se.happeningButton,
                        testID: q,
                        type: "secondary"
                    }, re))), s.createElement(M.a, {
                        style: [se.block, o && se.blockWide, se.communication]
                    }, s.createElement(I.a, {
                        style: [se.twitterIconBg, o ? se.twitterIconBgWide : se.twitterIconBgNarrow]
                    }), e._renderCommunicationItems()), o ? null : s.createElement(M.a, {
                        style: [se.block, se.bottomButtonsBlock]
                    }, s.createElement(N.a, {
                        link: "/i/flow/signup",
                        onPress: e._handleSignupButton,
                        style: [se.bottomButton, se.bottomButtonLeft],
                        type: "primary"
                    }, ae), s.createElement(N.a, {
                        link: "/login",
                        onPress: e._handleLoginButton,
                        style: [se.bottomButton, se.bottomButtonRight],
                        type: "secondary"
                    }, re))), s.createElement(u.a.Configure, {
                        hideEUBanner: !0
                    }), s.createElement(Q, null), s.createElement(f.a, {
                        align: "center"
                    })))
                }
                ))
            }
            ,
            n._renderCommunicationItems = function() {
                var e = ee.length;
                return s.createElement(M.a, {
                    style: se.communicationItems
                }, ee.map((function(t, n) {
                    var o = t.Icon
                      , a = t.text
                      , r = n + 1 === e;
                    return s.createElement(M.a, {
                        key: a,
                        style: [se.communicationItem, r && se.communicationItemLast]
                    }, s.createElement(o, {
                        style: se.communicationItemIcon
                    }), s.createElement(Y.b, {
                        color: "white",
                        size: "large",
                        style: se.communicationItemText,
                        weight: "bold"
                    }, a))
                }
                )))
            }
            ,
            n._renderLoginForm = function(e) {
                var t = this.state
                  , n = t.autoSubmit
                  , o = t.usernameValue
                  , a = o ? "?account_identifier=" + o : "";
                return s.createElement(M.a, {
                    style: [ce.container, e ? ce.centered : ce.leftAlignWithBlock]
                }, s.createElement(C.a, {
                    autoSubmit: n,
                    horizontalLayout: !0,
                    submitButtonStyle: ce.submitButtonStyle,
                    submitButtonType: "secondary"
                }, s.createElement(M.a, {
                    style: ce.inputContainer
                }, s.createElement($.b, {
                    onChange: this._handleUsernameChange,
                    onSubmitEditing: this._handleSubmitEditing,
                    style: ce.input
                })), s.createElement(M.a, {
                    style: ce.inputContainer
                }, s.createElement($.a, {
                    onSubmitEditing: this._handleSubmitEditing,
                    style: ce.input
                }), s.createElement(Y.b, {
                    link: {
                        pathname: "https://twitter.com/account/begin_password_reset" + a,
                        external: !0,
                        openInSameFrame: !0
                    },
                    size: "small",
                    style: ce.forgotPassword
                }, te))))
            }
            ,
            t
        }(s.Component)
          , ce = U.a.create((function(e) {
            return {
                container: {
                    alignItems: "center",
                    maxWidth: e.breakpoints.medium,
                    paddingHorizontal: e.spaces.small,
                    position: "absolute",
                    top: e.spaces.small
                },
                submitButtonStyle: {
                    marginBottom: e.spaces.xxSmall
                },
                centered: {
                    left: "0px",
                    maxWidth: "unset",
                    width: "100%"
                },
                leftAlignWithBlock: {
                    left: "calc(50% - 190px - " + e.spaces.small + ")"
                },
                inputContainer: {
                    flexShrink: 1,
                    width: "225px"
                },
                input: {
                    paddingLeft: 0,
                    paddingTop: 0,
                    paddingBottom: 0
                },
                forgotPassword: {
                    height: 0,
                    overflowY: "visible",
                    marginLeft: e.spaces.xSmall,
                    marginTop: e.spaces.xxSmall
                }
            }
        }
        ))
          , se = U.a.create((function(e) {
            return {
                block: {
                    justifyContent: "center",
                    padding: e.spaces.small
                },
                blocksWide: {
                    flex: 1,
                    flexDirection: "row-reverse"
                },
                blockWide: {
                    flex: 1
                },
                blockInnerWrapper: {
                    alignSelf: "center",
                    maxWidth: "380px"
                },
                bottomButton: {
                    flexGrow: 1,
                    maxWidth: "180px"
                },
                bottomButtonLeft: {
                    marginRight: "10px"
                },
                bottomButtonRight: {
                    marginLeft: "10px"
                },
                bottomButtonsBlock: {
                    flexDirection: "row",
                    paddingTop: e.spaces.xLarge,
                    paddingBottom: e.spaces.large
                },
                communication: {
                    backgroundColor: e.colors.lightBlue,
                    overflow: "hidden"
                },
                communicationItem: {
                    flexDirection: "row",
                    marginBottom: "40px"
                },
                communicationItemIcon: {
                    color: e.colors.white,
                    flexShrink: 0,
                    fontSize: e.fontSizes.xLarge
                },
                communicationItemLast: {
                    marginBottom: 0
                },
                communicationItems: {
                    alignSelf: "center",
                    maxWidth: "380px",
                    paddingVertical: e.spaces.small
                },
                communicationItemText: {
                    lineHeight: "30px",
                    marginLeft: e.spaces.small
                },
                main: {
                    minHeight: "auto"
                },
                happeningButton: {
                    marginBottom: e.spaces.small
                },
                joinToday: {
                    marginBottom: e.spaces.small,
                    marginTop: e.spaces.jumbo
                },
                root: {
                    flex: 1
                },
                seeWhatsHappening: {
                    marginTop: e.spaces.medium
                },
                twitterIcon: {
                    alignSelf: "flex-start",
                    color: e.colors.brandColor,
                    height: "2.75rem"
                },
                twitterIconBg: {
                    color: e.colors.blue,
                    maxWidth: "none",
                    position: "absolute"
                },
                twitterIconBgNarrow: {
                    height: "60vh",
                    top: "-10vh",
                    right: "-10vh"
                },
                twitterIconBgWide: {
                    height: "160vh",
                    top: "-30vh",
                    right: "-50vh"
                }
            }
        }
        ));
        t.default = Object(g.d)({
            page: "front"
        })(d(le))
    }
}]);
//# sourceMappingURL=https://ton.smf1.twitter.com/responsive-web-internal/sourcemaps/web/bundle.LoggedOutHome.feef9844.js.map
